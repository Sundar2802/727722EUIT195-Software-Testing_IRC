package com.example;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DemoBank {
    WebDriver driver;

    @BeforeMethod
    public void Testsetup() throws Exception {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://dbankdemo.com/bank/login");
    }

    @Test(priority = 1)
    public void TestCase1() throws Exception {
        FileInputStream fs = new FileInputStream("C:\\Users\\sunda\\Downloads\\DemoBankLogin.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(fs);
        XSSFSheet sheet1 = workbook.getSheet("LogIn");
        XSSFRow row = sheet1.getRow(1);
        String username = row.getCell(0).getStringCellValue();
        String password = row.getCell(1).getStringCellValue();
        System.out.println(username);
        System.out.println(password);
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        Thread.sleep(3000);
        driver.findElement(By.id("submit")).click();
    }

    @Test(priority = 2)
    public void TestCase2() throws Exception {
        FileInputStream fs = new FileInputStream("C:\\Users\\sunda\\Downloads\\DemoBankLogin.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(fs);
        XSSFSheet sheet1 = workbook.getSheet("LogIn");
        XSSFRow row = sheet1.getRow(1);
        String username = row.getCell(0).getStringCellValue();
        String password = row.getCell(1).getStringCellValue();
        System.out.println(username);
        System.out.println(password);
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        Thread.sleep(3000);
        driver.findElement(By.id("submit")).click();
        driver.findElement(By.linkText("Deposit")).click();
        WebElement ele1 = driver.findElement(By.id("selectedAccount"));
        Select dropdown = new Select(ele1);
        dropdown.selectByIndex(2);
        driver.findElement(By.id("amount")).sendKeys("5000");
        driver.findElement(By.xpath("//*[@id='right-panel']/div[2]/div/div/div/div/form/div[2]/button[1]")).click();
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("window.scrollBy(0,1200)");
    }

    @Test(priority = 3)
    public void TestCase3() throws Exception {
        FileInputStream fs = new FileInputStream("C:\\Users\\sunda\\Downloads\\DemoBankLogin.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(fs);
        XSSFSheet sheet1 = workbook.getSheet("LogIn");
        XSSFRow row = sheet1.getRow(1);
        String username = row.getCell(0).getStringCellValue();
        String password = row.getCell(1).getStringCellValue();
        System.out.println(username);
        System.out.println(password);
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        Thread.sleep(3000);
        driver.findElement(By.id("submit")).click();
        driver.findElement(By.linkText("Deposit")).click();
        WebElement ele1 = driver.findElement(By.id("selectedAccount"));
        Select dropdown = new Select(ele1);
        dropdown.selectByIndex(2);
        driver.findElement(By.id("amount")).sendKeys("3000");
        driver.findElement(By.xpath("//*[@id='right-panel']/div[2]/div/div/div/div/form/div[2]/button[1]")).click();
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("window.scrollBy(0,1200)");
    }

    @AfterMethod
    public void TestQuit() {
        driver.quit();
    }
}
